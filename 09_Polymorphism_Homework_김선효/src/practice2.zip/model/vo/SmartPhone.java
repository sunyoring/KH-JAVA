package practice2.model.vo;

public abstract class SmartPhone implements CellPhone,TouchDisplay{

	public SmartPhone() {
		// TODO Auto-generated constructor stub
	}
	public void printMaker() {
		
	}
}
