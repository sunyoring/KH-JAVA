package practice2.model.vo;

public interface Phone {

	public void makeaCall();
	public void takeaCall();
}
