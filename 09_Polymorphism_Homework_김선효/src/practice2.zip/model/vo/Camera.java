package practice2.model.vo;

public interface Camera {

	public void picture();// 촬영 방식

}
