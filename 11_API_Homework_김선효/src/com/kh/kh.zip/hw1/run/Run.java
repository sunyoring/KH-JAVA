package com.kh.hw1.run;

import com.kh.hw1.view.TokenMenu;

public class Run {

	public static void main(String[] args) {
		new TokenMenu().mainMenu();
	}

}
