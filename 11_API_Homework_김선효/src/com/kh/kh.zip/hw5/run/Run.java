package com.kh.hw5.run;

import com.kh.hw5.controller.NumberOk;

public class Run {

	public static void main(String[] args) {
		NumberOk no = new NumberOk();
		no.numGame();
	}

}
