package com.kh.hw2.run;

import com.kh.hw2.controller.SpaceUpper;

public class Run {

	public static void main(String[] args) {
		 new SpaceUpper().spaceToUpper();
	}

}
